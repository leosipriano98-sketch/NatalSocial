import { eq, and, count } from "drizzle-orm";
import { draws, votes } from "../drizzle/schema";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Verificar se um IP já realizou um sorteio
 * Garante que cada IP só pode sortear uma vez
 */
export async function hasUserDrawn(userIp: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check user draw: database not available");
    return false;
  }

  try {
    const result = await db
      .select()
      .from(draws)
      .where(eq(draws.userIp, userIp))
      .limit(1);

    return result.length > 0;
  } catch (error) {
    console.error("[Database] Error checking user draw:", error);
    return false;
  }
}

/**
 * Verificar se um nome já foi sorteado
 * Garante que cada pessoa só recebe uma vez
 */
export async function hasNameBeenDrawn(selectedName: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check drawn name: database not available");
    return false;
  }

  try {
    const result = await db
      .select()
      .from(draws)
      .where(eq(draws.selectedName, selectedName))
      .limit(1);

    return result.length > 0;
  } catch (error) {
    console.error("[Database] Error checking drawn name:", error);
    return false;
  }
}

/**
 * Verificar se um nome já realizou um sorteio
 * Garante que cada pessoa só entrega uma vez
 */
export async function hasNameDrawn(drawnByName: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check name that drew: database not available");
    return false;
  }

  try {
    const result = await db
      .select()
      .from(draws)
      .where(eq(draws.drawnByName, drawnByName))
      .limit(1);

    return result.length > 0;
  } catch (error) {
    console.error("[Database] Error checking name that drew:", error);
    return false;
  }
}

/**
 * Obter todos os sorteios realizados
 */
export async function getAllDraws() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get draws: database not available");
    return [];
  }

  try {
    return await db.select().from(draws);
  } catch (error) {
    console.error("[Database] Error getting all draws:", error);
    return [];
  }
}

/**
 * Registrar um novo sorteio com validações robustas
 * Garante:
 * 1. Cada IP só sorteia uma vez
 * 2. Cada pessoa só recebe uma vez
 * 3. Cada pessoa só entrega uma vez
 * 4. Nenhuma duplicação de dados
 */
export async function createDraw(drawnByName: string, selectedName: string, userIp: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create draw: database not available");
    return null;
  }

  try {
    // Validação 1: IP não pode sortear duas vezes
    const ipAlreadyDrawn = await hasUserDrawn(userIp);
    if (ipAlreadyDrawn) {
      throw new Error("Este IP já realizou um sorteio!");
    }

    // Validação 2: Nome não pode ser sorteado duas vezes
    const nameAlreadyDrawn = await hasNameBeenDrawn(selectedName);
    if (nameAlreadyDrawn) {
      throw new Error(`${selectedName} já foi sorteado!`);
    }

    // Validação 3: Nome não pode sortear duas vezes
    const nameAlreadyDrew = await hasNameDrawn(drawnByName);
    if (nameAlreadyDrew) {
      throw new Error(`${drawnByName} já realizou um sorteio!`);
    }

    // Validação 4: Não pode sortear a si mesmo
    if (drawnByName === selectedName) {
      throw new Error("Você não pode sortear a si mesmo!");
    }

    // Inserir o sorteio com todas as validações passadas
    const result = await db.insert(draws).values({
      drawnByName,
      selectedName,
      userIp,
    });

    return result;
  } catch (error) {
    console.error("[Database] Error creating draw:", error);
    throw error;
  }
}

/**
 * Verificar se um IP já votou em um participante em uma categoria
 * Garante que cada IP só pode votar uma vez em cada participante por categoria
 */
export async function hasUserVoted(participantName: string, userIp: string, category: 'social-do-ano' | 'social-revelacao'): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check user vote: database not available");
    return false;
  }

  try {
    const result = await db
      .select()
      .from(votes)
      .where(and(
        eq(votes.participantName, participantName),
        eq(votes.userIp, userIp),
        eq(votes.category, category)
      ))
      .limit(1);

    return result.length > 0;
  } catch (error) {
    console.error("[Database] Error checking user vote:", error);
    return false;
  }
}

/**
 * Registrar um novo voto em uma categoria
 */
export async function createVote(participantName: string, userIp: string, category: 'social-do-ano' | 'social-revelacao') {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create vote: database not available");
    return null;
  }

  try {
    // Validação: IP não pode votar duas vezes no mesmo participante na mesma categoria
    const alreadyVoted = await hasUserVoted(participantName, userIp, category);
    if (alreadyVoted) {
      throw new Error("Você já votou neste participante nesta categoria!");
    }

    // Inserir o voto
    const result = await db.insert(votes).values({
      category,
      participantName,
      userIp,
    });

    return result;
  } catch (error) {
    console.error("[Database] Error creating vote:", error);
    throw error;
  }
}

/**
 * Obter contagem de votos para todos os participantes em uma categoria
 */
export async function getVoteCounts(category: 'social-do-ano' | 'social-revelacao') {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get vote counts: database not available");
    return [];
  }

  try {
    const result = await db
      .select({
        participantName: votes.participantName,
        voteCount: count(),
      })
      .from(votes)
      .where(eq(votes.category, category))
      .groupBy(votes.participantName);

    return result;
  } catch (error) {
    console.error("[Database] Error getting vote counts:", error);
    return [];
  }
}
