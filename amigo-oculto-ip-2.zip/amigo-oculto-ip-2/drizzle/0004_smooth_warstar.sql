CREATE TABLE `sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userIp` varchar(45) NOT NULL,
	`browserId` varchar(64) NOT NULL,
	`selectedName` varchar(255),
	`lastAccessAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sessions_id` PRIMARY KEY(`id`)
);
