CREATE TABLE `participants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userIp` varchar(45) NOT NULL,
	`browserId` varchar(64) NOT NULL,
	`participantName` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `participants_id` PRIMARY KEY(`id`)
);
