CREATE TABLE `votes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`participantName` varchar(255) NOT NULL,
	`userIp` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `votes_id` PRIMARY KEY(`id`)
);
