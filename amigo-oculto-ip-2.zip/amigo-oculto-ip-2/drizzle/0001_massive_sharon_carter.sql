CREATE TABLE `draws` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawnByName` varchar(255) NOT NULL,
	`selectedName` varchar(255) NOT NULL,
	`userIp` varchar(45) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `draws_id` PRIMARY KEY(`id`)
);
