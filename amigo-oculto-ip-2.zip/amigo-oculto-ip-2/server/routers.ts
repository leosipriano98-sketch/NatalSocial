import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { hasUserDrawn, createDraw, getAllDraws, hasNameBeenDrawn, hasNameDrawn, hasUserVoted, createVote, getVoteCounts } from "./db";
import { TRPCError } from "@trpc/server";

// Categorias de votação
export const VOTE_CATEGORIES = {
  "social-do-ano": {
    label: "Social do Ano",
    candidates: [
      "Jussira Miguel",
      "Leonardo Sipriano",
      "Neil Barros",
      "Fidel Miguel",
      "Anibal D'Avila",
      "Carlos Varela",
      "Elizabeth Claúdia",
      "Domingos Higino Songo",
      "Vasco Daniel",
      "Osvaldo Quississa",
    ],
  },
  "social-revelacao": {
    label: "Social Revelação",
    candidates: [
      "Ricardo Martins",
      "Fernando Miguel",
      "Jussira Miguel",
      "Leonardo Sipriano",
      "Neil Barros",
      "Fidel Miguel",
      "Anibal D'Avila",
      "Carlos Varela",
      "Elizabeth Claúdia",
      "Domingos Higino Songo",
      "Vasco Daniel",
      "Osvaldo Quississa",
      "Shaline",
      "Dadinho",
      "Mónica",
    ],
  },
};

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  draw: router({
    /**
     * Verificar se o IP já realizou um sorteio
     */
    hasUserDrawn: publicProcedure.query(async ({ ctx }) => {
      const userIp = ctx.req.headers["x-forwarded-for"] as string || ctx.req.socket?.remoteAddress || "unknown";
      const hasDrawn = await hasUserDrawn(userIp);
      return { hasDrawn };
    }),

    /**
     * Obter todos os sorteios realizados
     */
    getAll: publicProcedure.query(async () => {
      const allDraws = await getAllDraws();
      return allDraws;
    }),

    /**
     * Realizar um novo sorteio com validações robustas
     * Garante:
     * 1. Cada IP só sorteia uma vez
     * 2. Cada pessoa só recebe uma vez
     * 3. Cada pessoa só entrega uma vez
     * 4. Ninguém sorteia a si mesmo
     */
    create: publicProcedure
      .input(
        z.object({
          drawnByName: z.string().min(1, "Nome de quem sorteou é obrigatório"),
          selectedName: z.string().min(1, "Nome sorteado é obrigatório"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const userIp = ctx.req.headers["x-forwarded-for"] as string || ctx.req.socket?.remoteAddress || "unknown";
        
        // Validação 1: IP não pode sortear duas vezes
        const ipAlreadyDrawn = await hasUserDrawn(userIp);
        if (ipAlreadyDrawn) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Este IP já realizou um sorteio!",
          });
        }

        // Validação 2: Nome não pode ser sorteado duas vezes
        const nameAlreadyDrawn = await hasNameBeenDrawn(input.selectedName);
        if (nameAlreadyDrawn) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `${input.selectedName} já foi sorteado!`,
          });
        }

        // Validação 3: Nome não pode sortear duas vezes
        const nameAlreadyDrew = await hasNameDrawn(input.drawnByName);
        if (nameAlreadyDrew) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `${input.drawnByName} já realizou um sorteio!`,
          });
        }

        // Validação 4: Não pode sortear a si mesmo
        if (input.drawnByName === input.selectedName) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Você não pode sortear a si mesmo!",
          });
        }

        // Registrar o novo sorteio com todas as validações passadas
        try {
          const result = await createDraw(input.drawnByName, input.selectedName, userIp);
          return { success: true, result };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro ao criar sorteio";
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: errorMessage,
          });
        }
      }),
  }),

  vote: router({
    /**
     * Obter categorias de votação disponíveis
     */
    getCategories: publicProcedure
      .query(async () => {
        return VOTE_CATEGORIES;
      }),

    /**
     * Verificar se o IP já votou em um participante em uma categoria
     */
    hasUserVoted: publicProcedure
      .input(z.object({
        category: z.enum(["social-do-ano", "social-revelacao"]),
        participantName: z.string().min(1, "Nome do participante é obrigatório"),
      }))
      .query(async ({ input, ctx }) => {
        const userIp = ctx.req.headers["x-forwarded-for"] as string || ctx.req.socket?.remoteAddress || "unknown";
        const voted = await hasUserVoted(input.participantName, userIp, input.category);
        return { voted };
      }),

    /**
     * Obter contagem de votos para todos os participantes em uma categoria
     */
    getCounts: publicProcedure
      .input(z.object({
        category: z.enum(["social-do-ano", "social-revelacao"]),
      }))
      .query(async ({ input }) => {
        const voteCounts = await getVoteCounts(input.category);
        return voteCounts;
      }),

    /**
     * Registrar um novo voto em uma categoria
     */
    create: publicProcedure
      .input(z.object({
        category: z.enum(["social-do-ano", "social-revelacao"]),
        participantName: z.string().min(1, "Nome do participante é obrigatório"),
      }))
      .mutation(async ({ input, ctx }) => {
        const userIp = ctx.req.headers["x-forwarded-for"] as string || ctx.req.socket?.remoteAddress || "unknown";
        
        // Validação: IP não pode votar duas vezes no mesmo participante na mesma categoria
        const alreadyVoted = await hasUserVoted(input.participantName, userIp, input.category);
        if (alreadyVoted) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Você já votou neste participante nesta categoria!",
          });
        }

        // Registrar o novo voto
        try {
          const result = await createVote(input.participantName, userIp, input.category);
          return { success: true, result };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro ao registrar voto";
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: errorMessage,
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
