import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela para armazenar os sorteios realizados
 * Controla quem sorteou e quem foi sorteado
 * Também armazena o IP para impedir múltiplos sorteios do mesmo IP
 */
export const draws = mysqlTable("draws", {
  id: int("id").autoincrement().primaryKey(),
  /** Nome de quem sorteou */
  drawnByName: varchar("drawnByName", { length: 255 }).notNull(),
  /** Nome sorteado */
  selectedName: varchar("selectedName", { length: 255 }).notNull(),
  /** IP do usuário que realizou o sorteio */
  userIp: varchar("userIp", { length: 255 }).notNull(),
  /** Timestamp do sorteio */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Draw = typeof draws.$inferSelect;
export type InsertDraw = typeof draws.$inferInsert;

/**
 * Tabela para armazenar votos dos participantes
 * Controla quem votou em quem
 * Cada IP só pode votar uma vez em cada participante
 */
export const votes = mysqlTable("votes", {
  id: int("id").autoincrement().primaryKey(),
  /** Categoria do voto: social-do-ano ou social-revelacao */
  category: mysqlEnum("category", ["social-do-ano", "social-revelacao"]).notNull(),
  /** Nome do participante que recebeu o voto */
  participantName: varchar("participantName", { length: 255 }).notNull(),
  /** IP do usuário que votou */
  userIp: varchar("userIp", { length: 255 }).notNull(),
  /** Timestamp do voto */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Vote = typeof votes.$inferSelect;
export type InsertVote = typeof votes.$inferInsert;