import { describe, expect, it, beforeEach, afterEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { getDb } from "./db";
import { draws } from "../drizzle/schema";
import { eq } from "drizzle-orm";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

/**
 * Criar um contexto de teste para simular requisições
 */
function createTestContext(userIp: string): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {
        "x-forwarded-for": userIp,
      },
    } as any,
    res: {
      clearCookie: () => {},
    } as any,
  };

  return { ctx };
}

/**
 * Limpar dados de teste do banco de dados
 */
async function cleanupTestData(testIps: string[]) {
  const db = await getDb();
  if (!db) return;

  for (const ip of testIps) {
    await db.delete(draws).where(eq(draws.userIp, ip));
  }
}

describe("draw router", () => {
  describe("draw.hasUserDrawn", () => {
    it("should return false for a new IP", async () => {
      const testIp = "test-192.168.1.200";
      try {
        const { ctx } = createTestContext(testIp);
        const caller = appRouter.createCaller(ctx);

        const result = await caller.draw.hasUserDrawn();

        expect(result.hasDrawn).toBe(false);
      } finally {
        await cleanupTestData([testIp]);
      }
    });
  });

  describe("draw.getAll", () => {
    it("should return an array of draws", async () => {
      const testIp = "test-192.168.1.201";
      try {
        const { ctx } = createTestContext(testIp);
        const caller = appRouter.createCaller(ctx);

        const result = await caller.draw.getAll();

        expect(Array.isArray(result)).toBe(true);
      } finally {
        await cleanupTestData([testIp]);
      }
    });
  });

  describe("draw.create", () => {
    it("should create a new draw successfully", async () => {
      const testIp = "test-192.168.1.202";
      try {
        const { ctx } = createTestContext(testIp);
        const caller = appRouter.createCaller(ctx);

        const result = await caller.draw.create({
          drawnByName: "Test Person A",
          selectedName: "Test Person B",
        });

        expect(result.success).toBe(true);
      } finally {
        await cleanupTestData([testIp]);
      }
    });

    it("should prevent duplicate draws from the same IP", async () => {
      const testIp = "test-192.168.1.203";
      try {
        const { ctx: ctx1 } = createTestContext(testIp);
        const caller1 = appRouter.createCaller(ctx1);

        // First draw should succeed
        const result1 = await caller1.draw.create({
          drawnByName: "Test Person C",
          selectedName: "Test Person D",
        });

        expect(result1.success).toBe(true);

        // Second draw from the same IP should fail
        const { ctx: ctx2 } = createTestContext(testIp);
        const caller2 = appRouter.createCaller(ctx2);

        try {
          await caller2.draw.create({
            drawnByName: "Test Person E",
            selectedName: "Test Person F",
          });
          expect.fail("Should have thrown an error");
        } catch (error: any) {
          expect(error.message).toContain("já realizou um sorteio");
        }
      } finally {
        await cleanupTestData([testIp]);
      }
    });

    it("should validate input data", async () => {
      const testIp = "test-192.168.1.204";
      try {
        const { ctx } = createTestContext(testIp);
        const caller = appRouter.createCaller(ctx);

        try {
          await caller.draw.create({
            drawnByName: "",
            selectedName: "Test Person G",
          });
          expect.fail("Should have thrown a validation error");
        } catch (error: any) {
          expect(error.message).toBeDefined();
        }
      } finally {
        await cleanupTestData([testIp]);
      }
    });
  });
});
