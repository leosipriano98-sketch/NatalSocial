import { useState, useEffect, useMemo } from 'react';
import { Gift, Sparkles, ThumbsUp } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

// ============================================================================
// CONSTANTES
// ============================================================================

const NOMES = [
  'Aníbal D\'Avila',
  'Carlos Varela',
  'Deborah Almeida',
  'Domingos Higino Songo',
  'Elizabeth Claúdia',
  'Fidel Miguel',
  'Fernando Miguel',
  'Joana Fernandes',
  'José Carlos',
  'Jussira Miguel',
  'Leonardo Sipriano',
  'Neil Barros',
  'Osvaldo Quississa',
  'Ricardo Fernandes'
];

const DRAW_STORAGE_KEY = 'amigo-oculto-draw-status';
const DISPLAY_DURATION_MS = 5000; // 5 segundos

// Data de exibição dos resultados das votações
const RESULTS_DISPLAY_DATE = new Date('2025-12-06T12:00:00');

// ============================================================================
// TIPOS
// ============================================================================

interface DrawRecord {
  id?: number;
  drawnByName: string;
  selectedName: string;
  createdAt?: string | Date;
}

interface StoredDrawStatus {
  hasDrawn: boolean;
  timestamp: string;
}

interface VoteCount {
  participantName: string;
  voteCount: number;
}

interface VoteCategory {
  label: string;
  candidates: string[];
}

type VoteCategoryKey = 'social-do-ano' | 'social-revelacao';

// ============================================================================
// FUNÇÕES AUXILIARES
// ============================================================================

/**
 * Acessa localStorage de forma segura
 */
function safeLocalStorageGetItem(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch (error) {
    console.warn(`Erro ao ler localStorage[${key}]:`, error);
    return null;
  }
}

/**
 * Escreve em localStorage de forma segura
 */
function safeLocalStorageSetItem(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch (error) {
    console.warn(`Erro ao escrever localStorage[${key}]:`, error);
  }
}

/**
 * Remove item do localStorage de forma segura
 */
function safeLocalStorageRemoveItem(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.warn(`Erro ao remover localStorage[${key}]:`, error);
  }
}

/**
 * Verifica se o usuário já sorteou baseado no localStorage
 */
function checkLocalStorageDrawStatus(): boolean {
  try {
    const storedData = safeLocalStorageGetItem(DRAW_STORAGE_KEY);
    if (!storedData) return false;
    
    const parsed: StoredDrawStatus = JSON.parse(storedData);
    return parsed.hasDrawn === true;
  } catch (error) {
    console.error('Erro ao verificar localStorage:', error);
    safeLocalStorageRemoveItem(DRAW_STORAGE_KEY);
    return false;
  }
}

/**
 * Marca o sorteio como realizado no localStorage
 */
function markAsDrawnInStorage(): void {
  const status: StoredDrawStatus = {
    hasDrawn: true,
    timestamp: new Date().toISOString(),
  };
  safeLocalStorageSetItem(DRAW_STORAGE_KEY, JSON.stringify(status));
}

/**
 * Filtra nomes disponíveis para sorteio
 */
function filterAvailableNames(allNames: string[], drawnNames: string[]): string[] {
  return allNames.filter(name => !drawnNames.includes(name));
}

/**
 * Verifica se os resultados podem ser exibidos
 */
function canShowResults(): boolean {
  return new Date() >= RESULTS_DISPLAY_DATE;
}

/**
 * Formata a data de exibição dos resultados
 */
function formatResultsDate(): string {
  return RESULTS_DISPLAY_DATE.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export default function Home() {
  // =========================================================================
  // ESTADO
  // =========================================================================

  const [nomeSelecionado, setNomeSelecionado] = useState('');
  const [nomeSorteado, setNomeSorteado] = useState('');
  const [jasorteou, setJaSorteou] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [nomesSorteadores, setNomesSorteadores] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'sorteio' | 'votacao'>('sorteio');
  const [activeVoteCategory, setActiveVoteCategory] = useState<VoteCategoryKey>('social-do-ano');
  const [voteCounts, setVoteCounts] = useState<Record<VoteCategoryKey, VoteCount[]>>({
    'social-do-ano': [],
    'social-revelacao': [],
  });
  const [votandoEm, setVotandoEm] = useState<string | null>(null);
  const [canShowVoteResults, setCanShowVoteResults] = useState(false);

  // =========================================================================
  // QUERIES E MUTATIONS
  // =========================================================================

  const { data: allDrawsData, refetch: refetchDraws } = trpc.draw.getAll.useQuery();
  const createDrawMutation = trpc.draw.create.useMutation();
  
  const { data: voteCountsSocialAnoData, refetch: refetchVoteCountsSocialAno } = trpc.vote.getCounts.useQuery({ category: 'social-do-ano' });
  const { data: voteCountsSocialRevelacaoData, refetch: refetchVoteCountsSocialRevelacao } = trpc.vote.getCounts.useQuery({ category: 'social-revelacao' });
  
  const { data: hasUserVotedData } = trpc.vote.hasUserVoted.useQuery(
    { category: activeVoteCategory, participantName: votandoEm || '' },
    { enabled: !!votandoEm }
  );
  const createVoteMutation = trpc.vote.create.useMutation();
  const { data: categoriesData } = trpc.vote.getCategories.useQuery();

  // =========================================================================
  // COMPUTED
  // =========================================================================

  const nomesDisponiveis = useMemo(() => {
    return filterAvailableNames(NOMES, nomesSorteadores);
  }, [nomesSorteadores]);

  const currentCategoryLabel = useMemo(() => {
    if (activeVoteCategory === 'social-do-ano') return 'Social do Ano';
    return 'Social Revelação';
  }, [activeVoteCategory]);

  const currentCandidates = useMemo(() => {
    if (!categoriesData) return [];
    const category = categoriesData[activeVoteCategory];
    return category?.candidates || [];
  }, [categoriesData, activeVoteCategory]);

  // =========================================================================
  // EFEITOS
  // =========================================================================

  /**
   * Inicializa o componente e carrega dados do banco de dados
   */
  useEffect(() => {
    const initializeComponent = async () => {
      try {
        // Verifica se já sorteou
        const hasDrawn = checkLocalStorageDrawStatus();
        setJaSorteou(hasDrawn);

        // Carrega os sorteios
        if (allDrawsData) {
          const drawnByNames = Array.from(new Set(allDrawsData.map((draw: DrawRecord) => draw.drawnByName)));
          setNomesSorteadores(drawnByNames.sort());
        }

        // Verifica se pode exibir resultados
        setCanShowVoteResults(canShowResults());

        setIsInitialized(true);
      } catch (error) {
        console.error('Erro ao inicializar:', error);
        setIsInitialized(true);
      }
    };

    initializeComponent();
  }, [allDrawsData]);

  /**
   * Atualiza contagem de votos quando muda
   */
  useEffect(() => {
    if (voteCountsSocialAnoData) {
      setVoteCounts(prev => ({
        ...prev,
        'social-do-ano': voteCountsSocialAnoData,
      }));
    }
  }, [voteCountsSocialAnoData]);

  useEffect(() => {
    if (voteCountsSocialRevelacaoData) {
      setVoteCounts(prev => ({
        ...prev,
        'social-revelacao': voteCountsSocialRevelacaoData,
      }));
    }
  }, [voteCountsSocialRevelacaoData]);

  // =========================================================================
  // HANDLERS
  // =========================================================================

  /**
   * Realiza o sorteio
   */
  const handleSortear = async () => {
    if (!nomeSelecionado) {
      toast.error('Por favor, selecione seu nome!');
      return;
    }

    setCarregando(true);

    try {
      await createDrawMutation.mutateAsync({
        drawnByName: nomeSelecionado,
        selectedName: nomesDisponiveis[Math.floor(Math.random() * nomesDisponiveis.length)],
      });

      // Aguarda um pouco para sincronizar com o servidor
      await new Promise(resolve => setTimeout(resolve, 500));

      // Recarrega os dados
      await refetchDraws();
      
      // Marca como sorteado no localStorage
      markAsDrawnInStorage();
      setJaSorteou(true);
      setNomeSelecionado('');

      toast.success('Sorteio realizado com sucesso!');

      // Limpa o resultado após 5 segundos
      setTimeout(() => {
        setNomeSorteado('');
      }, DISPLAY_DURATION_MS);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao realizar sorteio';
      toast.error(errorMessage);
      console.error('Erro ao sortear:', error);
    } finally {
      setCarregando(false);
    }
  };

  /**
   * Registra um voto em uma categoria
   */
  const handleVotar = async (participantName: string) => {
    setVotandoEm(participantName);

    try {
      await createVoteMutation.mutateAsync({
        category: activeVoteCategory,
        participantName,
      });

      // Aguarda um pouco para sincronizar com o servidor
      await new Promise(resolve => setTimeout(resolve, 300));

      // Recarrega contagem de votos
      if (activeVoteCategory === 'social-do-ano') {
        await refetchVoteCountsSocialAno();
      } else {
        await refetchVoteCountsSocialRevelacao();
      }

      toast.success(`Voto registrado para ${participantName}!`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro ao registrar voto';
      toast.error(errorMessage);
      console.error('Erro ao votar:', error);
    } finally {
      setVotandoEm(null);
    }
  };

  // =========================================================================
  // RENDERIZAÇÃO
  // =========================================================================

  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-red-700 flex items-center justify-center">
        <div className="text-white text-xl sm:text-2xl font-bold">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-red-700 relative overflow-hidden flex flex-col">
      {/* Ícones decorativos - Hidden on mobile */}
      <div className="hidden sm:block absolute top-10 left-10 text-yellow-300 opacity-30 animate-pulse">
        <Gift size={60} />
      </div>
      <div className="hidden md:block absolute top-20 right-20 text-yellow-300 opacity-30 animate-pulse" style={{animationDelay: '0.5s'}}>
        <Sparkles size={50} />
      </div>
      <div className="hidden lg:block absolute bottom-20 left-20 text-yellow-300 opacity-30 animate-pulse" style={{animationDelay: '1s'}}>
        <Gift size={50} />
      </div>
      <div className="hidden lg:block absolute bottom-32 right-16 text-yellow-300 opacity-30 animate-pulse" style={{animationDelay: '1.5s'}}>
        <Sparkles size={55} />
      </div>

      {/* Conteúdo principal */}
      <div className="relative z-10 flex-1 flex flex-col container mx-auto px-3 sm:px-4 py-6 sm:py-12 overflow-y-auto">
        {/* Título - Responsive */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-center text-yellow-300 mb-2" style={{
          fontFamily: 'Georgia, serif',
          textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
          letterSpacing: '1px',
          WebkitTextStroke: '0.5px rgba(0,0,0,0.2)'
        }}>
          🎄 Natal Social 🎅
        </h1>
        <p className="text-center text-yellow-100 text-lg sm:text-xl mb-4" style={{textShadow: '1px 1px 2px rgba(0,0,0,0.5)'}}>
          Amigo Oculto
        </p>

        {/* Espaçamento responsivo */}
        <div style={{height: 'clamp(2rem, 10vw, 100px)'}}></div>

        {/* Card principal - Responsive */}
        <div className="w-full max-w-2xl mx-auto bg-white rounded-xl sm:rounded-2xl shadow-2xl p-4 sm:p-6 md:p-8 flex-shrink-0">
          {/* Abas */}
          <div className="flex gap-2 mb-6 border-b-2 border-gray-200">
            <button
              onClick={() => setActiveTab('sorteio')}
              className={`flex-1 py-3 px-4 font-bold text-center transition-all ${
                activeTab === 'sorteio'
                  ? 'text-red-700 border-b-4 border-red-700 bg-red-50'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              🎁 Sorteio
            </button>
            <button
              onClick={() => setActiveTab('votacao')}
              className={`flex-1 py-3 px-4 font-bold text-center transition-all ${
                activeTab === 'votacao'
                  ? 'text-blue-700 border-b-4 border-blue-700 bg-blue-50'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              👍 Votação
            </button>
          </div>

          {/* Conteúdo da aba Sorteio */}
          {activeTab === 'sorteio' && (
            <div className="space-y-4 sm:space-y-6">
              {/* Aviso se já sorteou */}
              {jasorteou && (
                <div className="bg-yellow-100 border-2 border-yellow-400 rounded-lg p-3 sm:p-4">
                  <p className="text-yellow-800 font-bold text-center text-sm sm:text-base">
                    🎁 Realize aqui o seu sorteio
                  </p>
                </div>
              )}

              {/* Seleção de nome */}
              <div>
                <label className="block text-gray-700 font-bold mb-2 text-sm sm:text-base">
                  Selecione o seu nome:
                </label>
                <select
                  value={nomeSelecionado}
                  onChange={(e) => setNomeSelecionado(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-red-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 text-gray-800 font-semibold text-sm sm:text-base"
                >
                  <option value="">-- Escolha seu nome --</option>
                  {NOMES.map((nome) => (
                    <option key={nome} value={nome}>
                      {nome}
                    </option>
                  ))}
                </select>
              </div>

              {/* Resultado do sorteio */}
              {nomeSorteado && (
                <div className="bg-green-100 border-2 border-green-400 rounded-lg p-4 text-center animate-bounce">
                  <p className="text-green-800 font-bold text-lg sm:text-xl">
                    🎉 Você tirou: <span className="text-green-700">{nomeSorteado}</span>
                  </p>
                </div>
              )}

              {/* Botão de sorteio */}
              <div className="flex gap-3">
                <div className="flex-1">
                  <p className="text-gray-600 text-center text-sm mb-2">Você tirou:</p>
                  <div className="bg-red-50 border-2 border-red-700 rounded-lg p-3 text-center min-h-[50px] flex items-center justify-center">
                    <p className="text-red-700 font-bold text-sm sm:text-base">
                      {nomeSorteado || 'Clique em sortear'}
                    </p>
                  </div>
                </div>
                <Button
                  onClick={handleSortear}
                  disabled={carregando || !nomeSelecionado}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold transition-all active:scale-95 disabled:bg-gray-400 disabled:cursor-not-allowed min-h-[50px] flex items-center justify-center"
                >
                  <Gift size={20} className="mr-2" />
                  <span className="hidden sm:inline">{carregando ? 'Sorteando...' : 'Sortear'}</span>
                </Button>
              </div>

              {/* Estatísticas */}
              <div className="bg-gray-50 rounded-lg p-4 border-2 border-gray-200">
                <p className="text-gray-700 font-bold text-center text-sm sm:text-base">
                  Sorteios realizados: <span className="text-red-700">{nomesSorteadores.length} / 14</span>
                </p>
              </div>
            </div>
          )}

          {/* Conteúdo da aba Votação */}
          {activeTab === 'votacao' && (
            <div className="space-y-4 sm:space-y-6">
              {/* Seletor de categoria */}
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveVoteCategory('social-do-ano')}
                  className={`flex-1 py-2 px-3 font-bold text-center rounded-lg transition-all text-sm sm:text-base ${
                    activeVoteCategory === 'social-do-ano'
                      ? 'bg-purple-600 text-white border-2 border-purple-700'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  ⭐ Social do Ano
                </button>
                <button
                  onClick={() => setActiveVoteCategory('social-revelacao')}
                  className={`flex-1 py-2 px-3 font-bold text-center rounded-lg transition-all text-sm sm:text-base ${
                    activeVoteCategory === 'social-revelacao'
                      ? 'bg-orange-600 text-white border-2 border-orange-700'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  🌟 Social Revelação
                </button>
              </div>

              {/* Aviso sobre resultados */}
              {!canShowVoteResults && (
                <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-3 sm:p-4">
                  <p className="text-blue-800 font-semibold text-sm sm:text-base text-center">
                    📅 Os resultados serão exibidos em {formatResultsDate()}
                  </p>
                </div>
              )}

              {/* Descrição */}
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2">
                  {currentCategoryLabel}
                </h3>
                <p className="text-gray-600 text-sm mb-4">Vote nos seus candidatos favoritos! Cada IP pode votar uma vez por categoria.</p>
              </div>

              {/* Grade de participantes para votação */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentCandidates.map((nome) => {
                  const voteCount = voteCounts[activeVoteCategory]?.find(v => v.participantName === nome)?.voteCount || 0;
                  const isVoting = votandoEm === nome;

                  return (
                    <div
                      key={nome}
                      className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 sm:p-4 border-2 border-blue-300 flex items-center justify-between hover:shadow-lg transition-all"
                    >
                      <div className="flex-1">
                        <p className="font-semibold text-gray-800 text-sm sm:text-base truncate">{nome}</p>
                        <p className="text-blue-700 font-bold text-sm">
                          👍 {canShowVoteResults ? voteCount : '?'} votos
                        </p>
                      </div>
                      <Button
                        onClick={() => handleVotar(nome)}
                        disabled={isVoting}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-3 sm:px-4 py-2 rounded-lg font-bold text-sm transition-all active:scale-95 disabled:bg-gray-400 disabled:cursor-not-allowed ml-2 flex items-center gap-1 min-h-[40px]"
                      >
                        <ThumbsUp size={16} />
                        <span className="hidden sm:inline">{isVoting ? 'Votando...' : 'Votar'}</span>
                      </Button>
                    </div>
                  );
                })}
              </div>

              {/* Ranking de mais votados */}
              {canShowVoteResults && voteCounts[activeVoteCategory]?.length > 0 && (
                <div className="bg-yellow-50 rounded-lg p-4 border-2 border-yellow-300">
                  <h3 className="text-base sm:text-lg font-bold text-yellow-800 mb-3">🏆 Ranking de Votos</h3>
                  <ol className="space-y-2">
                    {voteCounts[activeVoteCategory]
                      .sort((a, b) => b.voteCount - a.voteCount)
                      .slice(0, 5)
                      .map((item, index) => (
                        <li key={item.participantName} className="flex items-center text-sm sm:text-base">
                          <span className="inline-block w-8 h-8 bg-yellow-500 text-white rounded-full text-center font-bold mr-3 flex-shrink-0" style={{lineHeight: '2rem'}}>
                            {index + 1}
                          </span>
                          <span className="flex-1 text-gray-800">{item.participantName}</span>
                          <span className="font-bold text-yellow-700">{item.voteCount} 👍</span>
                        </li>
                      ))}
                  </ol>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Mensagem de Natal */}
        <div className="w-full max-w-3xl mx-auto mt-6 sm:mt-8 md:mt-12 text-center flex-shrink-0">
          <div className="bg-white bg-opacity-90 rounded-lg sm:rounded-xl p-4 sm:p-6 md:p-8 shadow-xl">
            <h2 className="text-2xl sm:text-3xl font-bold text-red-700 mb-3 sm:mb-4" style={{fontFamily: 'Georgia, serif'}}>
              ✨ O Espírito do Natal ✨
            </h2>
            <p className="text-gray-700 text-sm sm:text-base md:text-lg leading-relaxed">
              O Natal é tempo de partilha, amor e união. Mais do que presentes, 
              celebramos os laços que nos unem como família e amigos. Que este 
              amigo oculto seja uma expressão do carinho que sentimos uns pelos outros, 
              e que cada gesto seja repleto de alegria e gratidão. Feliz Natal a todos! 🎄❤️
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
